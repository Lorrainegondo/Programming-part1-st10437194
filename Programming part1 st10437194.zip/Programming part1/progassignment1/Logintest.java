
public class Logintest {
    private Login login;

    public Logintest(Login login) {
        this.login = login;
    }

    @Test
    public void testCheckUserNameValid() {
        Login login =  new Login();
        assertEquals("Kyl_1","Kyl_1");
    }

    @Test
    public void testCheckUserNameInvalid() {
        Login login = new Login();
        assertEquals("kyle!!!!!!!", "Kyle!!!!!!!");
    }

    @Test
    public void testCheckPasswordComplexityValid() {
        Login login = new Login();
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
            }
        
            private void assertTrue(boolean checkPasswordComplexity) {
                // TODO Auto-generated method stub
                throw new UnsupportedOperationException("Unimplemented method 'assertTrue'");
            }
        
            @Test
    public void testCheckPasswordComplexityInvalid() {
    Login login = new Login();
        assertTrue(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testCheckCellPhoneNumberValid() {
        assertTrue(login.checkCellPhoneNumber("+27812345678"));
    }

    @Test
    public void testCheckCellPhoneNumberInvalid() {
        assertTrue(login.checkCellPhoneNumber("0812345678"));
        assertTrue(login.checkCellPhoneNumber("+279123456"));
    }

    @Test
    public void testRegisterUser() {
        assertEquals("Registration successful. Welcome!", login.registerUser("user_name", "Valid1?pass", "+27812345678"));
            }
        
            private void assertEquals(String string, String registerUser) {
                // TODO Auto-generated method stub
                throw new UnsupportedOperationException("Unimplemented method 'assertEquals'");
            }
        
            @Test
    public void testLoginUserValid() {
        login.registerUser("user_name", "Valid1?pass", "+27812345678");
        assertTrue(login.loginUser("user_name", "Valid1?pass"));
    }

    @Test
    public void testLoginUserInvalid() {
        login.registerUser("user_name", "Valid1?pass", "+27812345678");
        assertTrue(login.loginUser("user_name", "WrongPass"));
    }
}
