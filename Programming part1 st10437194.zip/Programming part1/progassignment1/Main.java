 
import java.util.Scanner; //Main class
    //import org.w3c.dom.UserDataHandler;
     public class Main{
        public static void main(String[] args) {
            Scanner input = new Scanner(System.in);
            Login login = new Login();
    
            // === Registration ===
        System.out.println("===Registration=== ");
        System.out.println("Enter your username: ");
        String username=input.nextLine();
    
        System.out.print("Enter your password: ");
        String password =input.nextLine();
    
    
        System.out.print("Enter your phone number: ");
        String phone =input.nextLine(); 
    
    
        String registrationMessage = login.registerUser  (username,password,phone);
        System.out.print(registrationMessage);
    
    
        if (!registrationMessage.equals("User registered successfully")){
            System.out.print("Registration failed.Restart program.");
            input.close();
            return;
        }
        // === Login ===
        System.out.print("\n==== Login ====");
        System.out.println("Enter your username: ");
        String lp = input.nextLine();
    
    
        //String loginMessage = login.returnLoginStatus(lu, lp);
        //System.out.print(loginMessage);
    
        input.close();
        }
    
     }

